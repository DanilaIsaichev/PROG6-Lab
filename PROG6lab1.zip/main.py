import csv
from typing import List
from mathstats import MathStats


def main():

  # Считываем данные из файла Retail.csv
  data = read_data("Retail.csv")

  # Выводим количество уникальных элементов Invoice
  print(f"Number of Invoices: {count_invoice(data)}")

  # Выводим количество уникальных элементов StockCode
  print(f"Number of StockCodes: {count_different_values(data, 'StockCode')}")

  # Выводим количество элементов с StockCode 22178
  print(f"Number of 22178's items: {get_total_quantity(data, 22178)}\n")

  # Считываем данные из файла MarketingSpend.csv
  data2 = MathStats("MarketingSpend.csv").data

  # Выводим средние значения онлайн и офлайн продаж
  print(f"Mean: {MathStats('MarketingSpend.csv').get_mean(data2)}")

  # Выводим максимальные значения онлайн и офлайн продаж
  print(f"Maxs: {MathStats('MarketingSpend.csv').max}")

  # Выводим минимальные значения онлайн и офлайн продаж
  print(f"Mins: {MathStats('MarketingSpend.csv').min}\n")

  # Выводим дисперсию онлайн и офлайн продаж
  print(f"Dispersions: {MathStats('MarketingSpend.csv').disp}\n")

  # Выводим среднеквадратическое отклонение онлайн и офлайн продаж
  print(f"Standard deviations: {MathStats('MarketingSpend.csv').sigma_sq}\n")

  return 0
  

# Функция для считывания данных из файла  
def read_data(file_name: str) -> List[dict]:

  # Объявляем список
  result = []
  
  # Открываем файл на чтение
  file = open(file_name, 'r')

  # Считываем содержимое файла
  data = csv.DictReader(file)

  # Обрабатываем все строки
  for _line in data:
      
    # Приводим данные к int
    _line["InvoiceNo"] = int(_line["InvoiceNo"])
    _line["StockCode"] = int(_line["StockCode"])
    _line["Quantity"] = int(_line["Quantity"])

    # Добавляем данные в список
    result.append(_line)

  return result


# Функция определения количества уникальных элементов Invoice
def count_invoice(data: List[dict]) -> int:

  # Объявляем счётчик
  count = 0

  """
  # --- Через список ---

  # Объявляем список
  elements = []

  # Обрабатываем данные
  for _element in data:

    # Проверяем, содержатся ли данные в списке
    if _element["InvoiceNo"] not in elements:

      # Добавляем данные в список
      elements.append(_element["InvoiceNo"])

      # Увеличиваем счётчик
      count += 1

  """

  """
  # --- Через множество ---

  # Объявляем множество
  elements = set()

  # Обрабатываем данные
  for _element in data:

    # Добавляем данные в множество (добавляются только неповторяющиеся данные)
    elements.add(_element["InvoiceNo"])

  # Определяем размер множества
  count = len(elements)

  """

  # --- Через Counter ---

  from collections import Counter

  # Объявляем список
  elements = [
  
    # Обрабатываем данные
    _element["InvoiceNo"] for _element in data
    
  ]
    
  # Определяем количество уникальных элементов через количество элементов счётчика
  count = len(Counter(elements))
  
  return count


# Функция определения количества уникальных элементов key
def count_different_values(data: List[dict], key: str) -> int:

  # Объявляем счётчик
  count = 0

  """
  # --- Через список ---

  # Объявляем список
  elements = []

  # Обрабатываем данные
  for _element in data:

    # Проверяем, содержатся ли данные в списке
    if _element[key] not in elements:

      # Добавляем данные в список
      elements.append(_element[key])

      # Увеличиваем счётчик
      count += 1
  """

  """
  # --- Через множество ---

  # Объявляем множество
  elements = set()

  # Обрабатываем данные
  for _element in data:

    # Добавляем данные в множество (добавляются только неповторяющиеся данные)
    elements.add(_element[key])

  # Определяем размер множества
  count = len(elements)
  """

  
  # --- Через Counter ---

  from collections import Counter

  # Объявляем список
  elements = [
    
    # Обрабатываем данные
    _element[key] for _element in data
    
  ]
    
  # Определяем количество уникальных элементов через количество элементов счётчика
  count = len(Counter(elements))
  
  
  return count

  
# Функция, вычисляющая количество товаров по соответствущему StokCode
def get_total_quantity(data: List[dict], stockcode: int) -> int:
#посчитать количество товаров определённого stokcode

  # Объявляем счётчик
  counter = 0
  
  # Обрабатываем данные
  for _element in data:

    # Проверяем, совпадает ли StockCode в записи с введённым
    if _element["StockCode"] == stockcode:

      # Увеличиваем счётчик на число единиц товара в записи
      counter += _element["Quantity"]
  
  return counter


if __name__ == '__main__':
  main()
