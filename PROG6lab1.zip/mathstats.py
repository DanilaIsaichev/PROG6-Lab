"""
Для вычисления дисперсии и ср. квадр. отклонения использовать 
https://myslide.ru/documents_3/b9d7b50c38e81a4b8b7645742d3b22c7/img10.jpg


"""


class MathStats():
    def __init__(self, file):

      # Импортируем библиотеку CSV
      import csv

      # Объявляем свойство для хранения имени файла
      self._file = file

      # Объявляем свойство для хранения содержимого файла
      self._data = []

      # Объявляем свойство для хранения средних значений
      self._mean = None

      # Объявляем свойство для хранения максимальных значений
      self._max = None

      # Объявляем свойство для хранения минимльных значений
      self._min = None

      # Считываем содержимое файла
      for _r in csv.DictReader(open(self._file, newline='')):

        # Считываем элемент из файла
        row = {
          
          # Записываем дату
          'Date': _r[''],

          # Приводим к типу float и записываем офлайн продажу
          'Offline': float(_r['Offline Spend']),

          # Приводим к типу float и записываем онлайн продажу
          'Online': float(_r['Online Spend']),
        }

        # Записываем элемент в data
        self._data.append(row)

    @property
    def data(self):
        return self._data

    def get_mean(self, data):
      
      # Объявляем словарь для вычисления среднего значения для онлайн и офлайн продаж
      sums = {'offline': 0, 'online': 0}

      # Обрабатываем все элементы из файла
      for _element in data:

        # Суммируем онлайн продажи
        sums['online'] += _element['Online']
        
        # Суммируем офлайн продажи
        sums['offline'] += _element['Offline']

      #Вычисляем среднее значение онлайн продаж
      sums['online'] /= len(data)
      
      #Вычисляем среднее значение офлайн продаж
      sums['offline'] /= len(data)
      
      # Передаём значения словаря средних значений
      self._mean = sums

      return self._mean

    @property
    def max(self):

      # Объявляем словарь для определения максимальных элементов
      maxs = {'offline': float('-Inf'), 'online': float('-Inf')}
      
      # Обрабатываем все элементы из файла
      for _element in self._data:
        
        # Проверяем, больше ли текущий онлайн элемент, чем максимальный онлайн элемент
        if _element['Online'] > maxs['online']:
          
          # Присваиваем значение текущего онлайн элемента максимальному онлайн элементу
          maxs['online'] = _element['Online']
          
        # Проверяем, больше ли текущий офлайн элемент, чем максимальный офлайн элемент
        if _element['Offline'] > maxs['offline']:
          
          # Присваиваем значение текущего офлайн элемента максимальному офлайн элементу
          maxs['offline'] = _element['Offline']

      # Передаём значения словаря максимальных значений
      self._max = maxs
        
      return self._max

    @property
    def min(self):

      # Объявляем словарь для определения минимальных элементов
      mins = {'offline': float('Inf'), 'online': float('Inf')}
      
      # Обрабатываем все элементы из файла
      for _element in self._data:

        # Проверяем, меньше ли текущий онлайн элемент, чем минимальный онлайн элемент
        if _element['Online'] < mins['online']:

          # Присваиваем значение текущего онлайн элемента минимальному онлайн элементу
          mins['online'] = _element['Online']

        # Проверяем, меньше ли текущий офлайн элемент, чем минимальный офлайн элемент
        if _element['Offline'] < mins['offline']:
          # Присваиваем значение текущего офлайн элемента минимальному офлайн элементу
          mins['offline'] = _element['Offline']

      # Передаём значения словаря минимальных значений
      self._min = mins
          
      return self._min

    @property
    def disp(self):
      
      # Вычисляем средние значения
      mean = self.get_mean(self._data)

      # Объявляем словарь для вычисления дисперсии для онлайн и офлайн продаж
      sums = {'offline': 0, 'online': 0}
      
      # Вычисляем суммы
      for _element in self._data:

        # Суммируем онлайн продажи
        sums['online'] += (_element['Online'] - mean['online']) * (_element['Online'] - mean['online'])

        # Суммируем офлайн продажи
        sums['offline'] += (_element['Offline'] - mean['offline']) * (_element['Offline'] - mean['offline'])

      # Вычисляем дисперсию онлайн продаж
      sums['online'] /= len(self._data)

      # Вычисляем дисперсию офлайн продаж
      sums['offline'] /= len(self._data)

      # Передаём значения словаря дисперсий
      self._disp = sums
      
      return self._disp

    # по аналогии — со среднем квадратичным отклонением
    @property
    def sigma_sq(self):

      # Импортируем функцию вычисления квадратного корня 
      from math import sqrt

      # Объявляем словарь для вычисления среднеквадратических отклонений
      sums = {'offline': 0, 'online': 0}

      # Вычисляем квадратный корень из дисперсии онлайн продаж (Среднеквадратическое отклонение онлайн продаж)
      sums['online'] = sqrt(self.disp['online'])

      # Вычисляем квадратный корень из дисперсии офлайн продаж (Среднеквадратическое отклонение офлайн продаж)
      sums['offline'] = sqrt(self.disp['offline'])
      
      # Передаём значения словаря среднеквадратических отклонений
      self._sigma_sq = sums
      
      return self._sigma_sq